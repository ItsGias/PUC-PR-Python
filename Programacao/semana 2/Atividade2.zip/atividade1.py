def main():
        print("----- MENU PRINCIPAL -----")
        print("")
        print("(1) Gerenciar Estudantes.")
        print("(2) Gerenciar Disciplinas.")
        print("(3) Gerenciar Professores.")
        print("(4) Gerenciar Turmas.")
        print("(5) Gerenciar Matrículas.")
        print("(9) Sair.")
        print("")
        opcao_principal = input("Selecione uma opção: ")

        if opcao_principal == "1":
            print("")
            print("[ESTUDANTES] MENU DE OPERACOES:")
            print("(1) Incluir.")
            print("(2) Listar.")
            print("(3) Atualizar.")
            print("(4) Excluir")
            print("(9) Voltar ao menu principal.")
            print("")
            opcao_operacoes = input("Informe a opcao desejada: ")

        if opcao_principal == "2":
            print("")
            print("[DISCIPLINAS] MENU DE OPERACOES:")
            print("(1) Incluir.")
            print("(2) Listar.")
            print("(3) Atualizar.")
            print("(4) Excluir")
            print("(9) Voltar ao menu principal.")
            print("")
            opcao_operacoes = input("Informe a opcao desejada: ")

        if opcao_principal == "3":
            print("")
            print("[PROFESSORES] MENU DE OPERACOES:")
            print("(1) Incluir.")
            print("(2) Listar.")
            print("(3) Atualizar.")
            print("(4) Excluir")
            print("(9) Voltar ao menu principal.")
            print("")
            opcao_operacoes = input("Informe a opcao desejada: ")

        if opcao_principal == "4":
            print("")
            print("[TURMAS] MENU DE OPERACOES:")
            print("(1) Incluir.")
            print("(2) Listar.")
            print("(3) Atualizar.")
            print("(4) Excluir")
            print("(9) Voltar ao menu principal.")
            print("")
            opcao_operacoes = input("Informe a opcao desejada: ")

        if opcao_principal == "5":
            print("")
            print("[MATRICULAS] MENU DE OPERACOES:")
            print("")
            print("(1) Incluir.")
            print("(2) Listar.")
            print("(3) Atualizar.")
            print("(4) Excluir")
            print("(9) Voltar ao menu principal.")
            print("")
            opcao_operacoes = input("Informe a opcao desejada: ")

        if opcao_principal == "9":
            print("")

        print("")
        print("===== ATUALIZACAO =====")
        print("")

        print("Finalizando aplicacao...")

if __name__ == "__main__":
    main()

